$.noConflict();

jQuery(document).ready(function($) {
	init();
});
function init(){
	console.log("Inicializada tabla")
}